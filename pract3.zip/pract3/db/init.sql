CREATE DATABASE IF NOT EXISTS news;
CREATE USER IF NOT EXISTS 'user'@'%' IDENTIFIED BY 'password';
GRANT SELECT,UPDATE,INSERT,DELETE ON news.* TO 'user'@'%';
FLUSH PRIVILEGES;

USE news;

CREATE TABLE IF NOT EXISTS authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(26) NOT NULL,
    email VARCHAR(30) NOT NULL
);

INSERT INTO authors (name, email) VALUES
('Jonds', 'jonds@example.com'),
('Vulcore', 'vulcore@example.com'),
('Killtoo', 'killtoo@example.com'),
('Generator', 'generator@example.com'),
('Savitar', 'savitar@example.com'),
('Fridj', 'fridj@example.com'),
('Kensin', 'kensin@example.com'),
('Arny', 'arny@example.com');

CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    author_id INT NOT NULL,
    FOREIGN KEY (author_id) REFERENCES authors(id)
);

INSERT INTO articles (title, content, author_id) VALUES
(
    'Loki Season 2 Viewership Is Seemingly Off to a Strong Start, but Behind The Mandalorian Season 3',
    "In what appears to be a bit of good news for the Marvel Cinematic Universe, which has had its fair share of ups and downs in 2023, Loki Season 2 is seemingly off to a solid start.",
    3
),
(
    "Minecraft Players Trying to Stop Mob Vote With Propaganda Posters and More Than 220,000 Signatures",
    "Since 2016, Mojang has been hosting an annual mob vote that lets players choose the next creature it adds to Minecraft. In recent years, though, players have grown increasingly unhappy with the tradition, and this year they've taken to 'unionizing' to express their disappointment.",
    2
),
(
    "This is the Crazy Reason Guillermo Del Toro Didn't Do Pacific Rim 2 - IGN The Fix: Entertainment",
    "Guillermo Del Toro didn't direct the sequel to his kaiju vs giant robots movie, Pacific Rim, but he almost did. Speaking with Collider, Del Toro revealed the insane reason why he didn't, and it's probably not something you'd think of. In other movie news, Matt Shackman, who's on deck to direct the MCU version of the Fantastic Four, says the movie should begin filming next year. In fact, as early as Spring 2024, depending on how long the SAG-AFTRA strike lasts.",
    1
),
(
    'Activision Blizzard Shares Xbox Game Pass Plans, Leaves Door Open for Diablo IV on Game Pass in 2024',
    "Activision Blizzard has given the first glimpse of their plans for Xbox Game Pass once the Microsoft deal has closed, saying they expect to start bringing their games to the service next year.",
    6
),
(
    'Today I Learned the Original iMac Had a Touchscreen Variant',
    "While many of us wonder when Apple will make a Mac with touchscreen support, a Mac product already included touchscreen support over two decades ago.",
    5
),
(
    'The Crown Season 6 Release Date and Teaser Trailer Revealed',
    "Alongside revealing a short teaser, Netflix has announced that the sixth and final season of The Crown will be released in two parts, with the first four episodes arriving on November 16 and the last six following on December 14.",
    4
),
(
    'Joker Helped Joaquin Phoenix Land The Role Of Napoleon',
    "It turns out Ridley Scott was a big fan of Joaquin Phoenix's Joker.",
    7
),
(
    "Guillermo Del Toro Reveals Crazy Reason He Didn't Make Pacific Rim 2'",
    "Pacific Rim director Guillermo Del Toro has revealed the crazy reason he didn't make Pacific Rim 2: because someone failed to make a deposit.",
    8
);