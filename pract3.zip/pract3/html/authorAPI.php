<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    require_once "author.php";
    require_once 'authorDB.php';

    $authorDB = new AuthorDB();

    $method = $_SERVER["REQUEST_METHOD"];
    $limit = 100;
    if($method === 'GET'){
        if(isset($_GET["id"])){
            $id = $_GET["id"];
            $author = $authorDB->getAuthorJSONByID($id);
            if($author){
                http_response_code(200);
                echo json_encode($author);
            }else{
                http_response_code(404);
                echo json_encode(array("message" => "Author not found"));
            }
        }else{
            $authors = $authorDB->getAuthorByJSON($limit);
            if($authors){
                http_response_code(200);
                echo json_encode($authors);
            }else{
                http_response_code(404);
                echo json_encode(array("message" => "Authors not found"));
            }
        }
    }
    elseif($method === 'POST'){
        $data = json_decode(file_get_contents("php://input"));
        if(isset($data->name)){
            $success = $authorDB->addAuthor($data);
            if($success){
                http_response_code(201);
                echo json_encode(array("message" => "Author was created."));
            }else{
                http_response_code(503);
                echo json_encode(array("message" => "Unable to create author."));
            }
        }
    }
    elseif($method === 'PUT'){
        $data = json_decode(file_get_contents("php://input"));
        if(isset($data->id) && isset($data->name)){
            $success = $authorDB->updateAuthor($data);
            if($success){
                http_response_code(200);
                echo json_encode(array("message" => "Author was updated."));
            }else{
                http_response_code(503);
                echo json_encode(array("message" => "Unable to update author."));
            }
        }
    }
    elseif($method === 'DELETE'){
        $data = json_decode(file_get_contents("php://input"));
        if(isset($data->id)){
            $success = $authorDB->deleteAuthor($data->id);
            if($success){
                http_response_code(200);
                echo json_encode(array("message" => "Author was deleted."));
            }else{
                http_response_code(503);
                echo json_encode(array("message" => "Unable to delete author."));
            }
        }
    }
    else{
        http_response_code(405);
        echo json_encode(array("message" => "Method not allowed"));
        echo "CC";
    }
?>