<?php
    include_once "db.php";
    include_once "author.php";

    class AuthorDB extends Database{
        public function getAuthor($limit){
            $sql = "SELECT * FROM authors LIMIT $limit";
            $result = $this->db->query($sql);
            $authors = array();
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $author = new Author($row["id"], $row["name"], $row["email"]);
                    array_push($authors, $author);
                }
            }
            return $authors;
        }

        public function addAuthor($author){
            $sql = "INSERT INTO authors (name, email) VALUES ('$author->name', '$author->email')";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function deleteAuthor($id){
            $sql = "DELETE FROM authors WHERE id = $id";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function updateAuthor($author){
            $sql = "UPDATE authors SET name = '$author->name', email = '$author->email' WHERE id = $author->id";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function getAuthorByJSON($limit){
            $authors = $this->getAuthor($limit);
            $authorsJSON = [];
            foreach($authors as $author){
                $authorsJSON[] = [
                  'id' => $author->getId(),
                  'name' => $author->getName(),
                  'email' => $author->getEmail()
                ];
            }
            return $authorsJSON;
        }

        public function getAuthorByID($id){
            $sql = "SELECT * FROM authors WHERE id = $id";
            $result = $this->db->query($sql);
            if($result->num_rows > 0){
                $row = $result->fetch_assoc();
                $author = new author($row["id"], $row["name"], $row["email"]);
                return $author;
            }
            return null;
        }

        public function getAuthorJSONByID($id){
            $author = $this->getAuthorByID($id);
            if($author != null){
                return [
                    'id' => $author->getId(),
                    'name' => $author->getName(),
                    'email' => $author->getEmail()
                ];
            }
            return $json;
        }

    }
?>