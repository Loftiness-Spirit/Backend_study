<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    require_once "article.php";
    require_once "articleDB.php";

    $articleDB = new ArticleDB();

    $method = $_SERVER["REQUEST_METHOD"];
    $limit = 100;

    if ($method === 'GET') {
        if (isset($_GET["id"])) {
            $id = $_GET["id"];
            $article = $articleDB->getArticleJSONByID($id);
            if ($article) {
                http_response_code(200);
                echo json_encode(array($article));
            } else {
                http_response_code(404);
                echo json_encode(array("message" => "Article not found"));
            }
        } else {
            $articles = $articleDB->getArticleByJSON($limit);
            if ($articles) {
                http_response_code(200);
                echo json_encode(array($articles));
            } else {
                http_response_code(404);
                echo json_encode(array("message" => "Articles not found"));
            }
        }
        } elseif ($method === 'POST') {
            $data = json_decode(file_get_contents("php://input"));
            if (isset($data->title)) {
                $success = $articleDB->addArticle($data);
                if ($success) {
                    http_response_code(201);
                    echo json_encode(array("message" => "Article was created."));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "Unable to create article."));
                }
            }
                        
        } elseif ($method === 'PUT') {
            $data = json_decode(file_get_contents("php://input"));
            if (isset($data->id) && isset($data->title)) {
                $success = $articleDB->updateArticle($data);
                if ($success) {
                    http_response_code(200);
                    echo json_encode(array("message" => "Article was updated."));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "Unable to update article."));
                }
            }
        } elseif ($method === 'DELETE') {
            $data = json_decode(file_get_contents("php://input"));
            if (isset($data->id)) {
                $success = $articleDB->deleteArticle($data->id);
                if ($success) {
                    http_response_code(200);
                    echo json_encode(array("message" => "Article was deleted."));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "Unable to delete article."));
                }
            }
        } else {
            http_response_code(405);
            echo json_encode(array("message" => "Method not allowed"));
        }
?>