<?php

    include_once "db.php";
    include_once "article.php";

    class ArticleDB extends Database{
        public function getArticle($limit){
            $sql = "SELECT * FROM articles LIMIT $limit";
            $result = $this->db->query($sql);
            $articles = array();
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $article = new Article($row["id"], $row["title"], $row["content"], $row["author_id"]);
                    array_push($articles, $article);
                }
            }
            return $articles;
        }

        public function addArticle($article){
            $sql = "INSERT INTO articles (title, content, author_id) VALUES ('$article->title', '$article->content', $article->author_id)";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function deleteArticle($id){
            $sql = "DELETE FROM articles WHERE id = $id";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function updateArticle($article){
            $sql = "UPDATE articles SET title = '$article->title', content = '$article->content', author_id = '$article->author_id' WHERE id = $article->id";
            $result = $this->db->query($sql);
            if($result){
                return true;
            }
            return false;
        }

        public function getArticleByJSON($limit){
            $articles = $this->getArticle($limit);
            $articlesJSON = [];
            foreach($articles as $article){
                $articlesJSON[] = [
                  'id' => $article->getId(),
                  'title' => $article->getTitle(),
                  'content' => $article->getContent(),
                  'author_id' => $article->getAuthorId()
                ];
            }
            return $articlesJSON;
        }

        public function getArticleByID($id){
            $sql = "SELECT * FROM articles WHERE id = $id";
            $result = $this->db->query($sql);
            if($result->num_rows > 0){
                $row = $result->fetch_assoc();
                $article = new Article($row["id"], $row["title"], $row["content"], $row["author_id"]);
                return $article;
            }
            return null;
        }

        public function getArticleJSONByID($id){
            $article = $this->getArticleByID($id);
            if($article != null){
                return [
                    'id' => $article->getId(),
                    'title' => $article->getTitle(),
                    'content' => $article->getContent(),
                    'author_id' => $article->getAuthorId()
                ];
            }
            return $json;
        }

    }

?>